// very simple and silly example of how the pure MessagePanelHandler plugins can be
// created using the provided plugin support. In this simple example, any messages
// containing the case sensitive keyword 'MapTool' will automatically bold the keyword
// before displaying it in the MessagePanel.

public class Filter
{
	public static String MessagePanelHandler(String Message)
	{
		Message = Message.replace("MapTool","<B>MapTool</B>");
		return Message;
	}
}