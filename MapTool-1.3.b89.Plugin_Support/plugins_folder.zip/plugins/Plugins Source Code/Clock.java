// Sample code to show how the pluginExecute can be used to senda place holder to
// other clients to be processed by the client's MessagePanelHandler events.
// In this case support for displaying the local client's date and time are
// provided. Note that by using the MessagePanelHandler instead of having the
// date and time determined by the pluginExecute (and sending the results to
// the clients) the date and time displayed will be that of each client as
// opposed to the date and time of the client that initiated the command.
// In this way, if clients are in different time zones the time shown for
// each client will be that client's local date and time.

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Clock
{
	// Processes the MapTool MessagePanel messages for Clock Plugin references
	// which are then replaced with the actual Date or Time. By implementing
	// the Plugin by using a MessagePanelHandler, the time will be reported by
	// each client as opposed to being determined by single client who initiated
	// the command. Thus if clients are in different time zones, this implementation
	// will show each client's current time as it applies to their time zone.
	public static String MessagePanelHandler(String Message)
	{
		// Format the current date and time
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss"); 
		Date date = new Date();
		// Process the replacement
		Message = Message.replace("{Plugin:Clock|Function:Date}",dateFormat.format(date));
		Message = Message.replace("{Plugin:Clock|Function:Time}",timeFormat.format(date));
		// Return the original messages (with possible replacements made)
		return Message;
	}

	public static String Date(String Params)
	{
		// Return a Date place holder. This will cause the Date place holder to be
		// sent to all applicable clients (as per the normal MapTool message rules).
		// Each client's MessagePanelHandler will then convert the place holder into
		// an actual local date unless they do not have the Clock plugin installed
		// in which case the client will see the below place holder making client
		// user aware that a plugin request was sent but not processed because the
		// Clock plugin was not installed.
		return "{Plugin:Clock|Function:Date}";
	}

	public static String Time(String Params)
	{
		// Return a Time place holder. This will cause the Time place holder to be
		// sent to all applicable clients (as per the normal MapTool message rules).
		// Each client's MessagePanelHandler will then convert the place holder into
		// an actual local time unless they do not have the Clock plugin installed
		// in which case the client will see the below place holder making client
		// user aware that a plugin request was sent but not processed because the
		// Clock plugin was not installed.
		return "{Plugin:Clock|Function:Time}";
	}

	public static String DateTime(String Params)
	{
		// Returns a Date and Time place holder. This place holder will be converted
		// by each client into an actual local date and time by the Clock Plugin
		// MessagePanelHandler unless the client does not have the Clock Plugin installed
		// in which case the below place holder will be visiable instead.
		return "{Plugin:Clock|Function:Date} {Plugin:Clock|Function:Time}";
	}
}