// Sample code showing an example of a pure pluginExecute plugin.
// The sample code allows reading of system parameters. For example,
// in MapTool, one can execute:
//
// Current OS is [r: plugins("SystemInfo","Get","os.name")].
//

public class SystemInfo
{
	public static String Get(String Setting)
	{
		return System.getProperty(Setting);
	}
}